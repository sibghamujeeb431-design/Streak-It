import { useEffect, useMemo, useReducer, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { DashboardLayout } from '../../components/DashboardLayout'
import { LabHeader } from '../../components/lab/LabHeader'
import { StepIndicator } from '../../components/lab/StepIndicator'
import { BiochemicalTestingBenchScene } from '../../components/lab/BiochemicalTestingBenchScene'
import { BiochemicalTestingObjectivePanel } from '../../components/lab/BiochemicalTestingObjectivePanel'
import { MentorPanel } from '../../components/lab/MentorPanel'
import { BiochemicalTestingInterpretQuiz } from '../../components/lab/BiochemicalTestingInterpretQuiz'
import { ExperimentCompleted } from '../../components/lab/ExperimentCompleted'
import {
  biochemicalTestingExperiment,
  TICK_MS,
  STEP_ORDER,
  buildMentorContext,
} from '../../data/biochemicalTesting'
import { INITIAL_STATE, labReducer } from '../../lib/biochemicalTestingMachine'
import { useAuth } from '../../context/useAuth'
import { saveAttempt } from '../../lib/experimentAttempts'
import referenceText from '../../../docs/StreakIt_AI_Lab_Mentor_Reference.md?raw'

const EXPERIMENT_NAME = biochemicalTestingExperiment.title
const STEPS = biochemicalTestingExperiment.steps

export function BiochemicalTestingLab() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [state, dispatch] = useReducer(labReducer, INITIAL_STATE)
  const savedRef = useRef(false)

  const currentStepId = STEP_ORDER[state.stepIndex]

  const mentorPrompt = useMemo(
    () => ({
      referenceText,
      contextString: buildMentorContext(
        currentStepId,
        state.phase,
        state.inoculationQuality,
        state.observedReactions.map((r) => r.tubeId),
        state.mistakes.length > 0
          ? state.mistakes[state.mistakes.length - 1]
          : null,
      ),
    }),
    [
      currentStepId,
      state.phase,
      state.inoculationQuality,
      state.observedReactions,
      state.mistakes,
    ],
  )

  // Timer tick effect.
  useEffect(() => {
    if (!state.timerRunning) return

    const interval = setInterval(() => {
      dispatch({ type: 'TICK' })
    }, TICK_MS)

    return () => clearInterval(interval)
  }, [state.timerRunning])

  // Save attempt when finished.
  useEffect(() => {
    if (!state.finished || !state.score || savedRef.current) return

    savedRef.current = true

    if (user) {
      saveAttempt(user.id, {
        experimentName: EXPERIMENT_NAME,
        score: state.score.overall,
        proceduralAccuracy: state.score.procedural,
        decisionAccuracy: state.score.decision,
        interpretationAccuracy: state.score.interpretation,
        mode: state.mode,
      }).catch((error) => {
        console.error('Failed to save attempt:', error)
      })
    }
  }, [state.finished, state.score, state.mode, user])

  function handleReset() {
    savedRef.current = false
    dispatch({ type: 'RESET' })
  }

  if (state.finished && state.score) {
    return (
      <DashboardLayout>
        <div className="max-w-3xl mx-auto">
          <ExperimentCompleted
            score={state.score}
            visual={
              <div className="flex gap-2 justify-center">
                <div className="w-8 h-16 border-2 border-stone/40 rounded-b-lg bg-gradient-to-b from-stone/5 to-stone/10" />
                <div className="w-8 h-16 border-2 border-stone/40 rounded-b-lg bg-gradient-to-b from-stone/5 to-stone/10" />
                <div className="w-8 h-16 border-2 border-stone/40 rounded-b-lg bg-gradient-to-b from-stone/5 to-stone/10" />
                <div className="w-8 h-16 border-2 border-stone/40 rounded-b-lg bg-gradient-to-b from-stone/5 to-stone/10" />
                <div className="w-8 h-16 border-2 border-stone/40 rounded-b-lg bg-gradient-to-b from-stone/5 to-stone/10" />
              </div>
            }
            experimentName={EXPERIMENT_NAME}
            mode={state.mode}
            onRetry={handleReset}
            onViewProgress={() => navigate('/progress')}
            onBackToExperiments={() => navigate('/experiments')}
          />
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto">
        <LabHeader
          title={EXPERIMENT_NAME}
          mode={state.mode}
          canChangeMode={
            state.stepIndex === 0 && state.phase === 'select' && state.selected.size === 0
          }
          onModeChange={(mode) => dispatch({ type: 'SET_MODE', payload: mode })}
          onExit={() => navigate('/experiments')}
        />

        <StepIndicator steps={STEPS} activeStep={state.stepIndex} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {state.stepIndex === 4 ? (
              <div className="bg-surface rounded-card border border-stone/10 p-8 space-y-8">
                <BiochemicalTestingInterpretQuiz
                  organismAnswer={state.answers.organism}
                  misconceptionAnswer={state.answers.misconception}
                  observedReactions={state.observedReactions}
                  onAnswer={(field, value) =>
                    dispatch({ type: 'ANSWER', payload: { field, value } })
                  }
                  onSubmit={() => dispatch({ type: 'SUBMIT_INTERPRETATION' })}
                />
              </div>
            ) : (
              <BiochemicalTestingBenchScene
                step={currentStepId}
                phase={state.phase}
                selected={state.selected}
                inoculationQuality={state.inoculationQuality}
                inoculatedTubes={state.inoculatedTubes}
                observedReactions={state.observedReactions}
                activeMistake={state.activeMistake}
                onSelectItem={(id) => dispatch({ type: 'SELECT_ITEM', payload: id })}
                onInoculateTube={(tubeId) => dispatch({ type: 'INOCULATE_TUBE', payload: tubeId })}
                onObserveTube={(tubeId) => dispatch({ type: 'OBSERVE_TUBE', payload: tubeId })}
              />
            )}

            <div className="hidden lg:block">
              <div className="flex items-center gap-3 bg-surface rounded-card border border-stone/10 px-5 py-4">
                <div className="w-8 h-8 rounded-full bg-teal/10 flex items-center justify-center">
                  <span className="text-teal text-xs font-bold">
                    {state.mode === 'test' ? 'T' : 'L'}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium text-charcoal">
                    {state.mode === 'test' ? 'Test Mode' : 'Learn Mode'}
                  </p>
                  <p className="text-xs text-stone">
                    {state.mode === 'test'
                      ? 'Mentor is disabled, timer requires manual stop'
                      : 'Mentor is available, timer auto-completes'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <BiochemicalTestingObjectivePanel
              step={currentStepId}
              phase={state.phase}
              mode={state.mode}
              timerMs={state.timerMs}
              inoculationQuality={state.inoculationQuality}
              inoculatedTubes={state.inoculatedTubes}
              observedReactions={state.observedReactions.map((r) => r.tubeId)}
              activeMistake={state.activeMistake}
              onConfirmPrepare={() => dispatch({ type: 'CONFIRM_PREPARE' })}
              onFinishInoculation={() => dispatch({ type: 'FINISH_INOCULATION' })}
              onStartIncubation={() => dispatch({ type: 'START_INCUBATION' })}
              onStopIncubation={() => dispatch({ type: 'STOP_INCUBATION' })}
              onFinishObservation={() => dispatch({ type: 'FINISH_OBSERVATION' })}
              onAdvance={() => dispatch({ type: 'ADVANCE' })}
              onDismissMistake={() => dispatch({ type: 'DISMISS_MISTAKE' })}
            />

            <MentorPanel
              mode={state.mode}
              prompt={mentorPrompt}
              greeting="I'm your AI Lab Mentor. Ask me anything about biochemical testing, enzyme reactions, or organism identification."
              fallbackHint="remember: identification is based on the full combination of test results, not any single test alone"
            />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
